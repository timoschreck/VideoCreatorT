# Online Musik Video Editor (Web Version)

Diese Version des Musikvideo‑Editors funktioniert komplett clientseitig im Browser und benötigt keine Installation von Node.js oder Electron. Sie können den Ordner auf einem Webserver (z. B. GitHub Pages) hosten oder die `index.html` lokal im Browser öffnen.

## Funktionen

Die Web‑Version bietet bereits viele grundlegende Bearbeitungsfunktionen:

* **Clips verwalten:** Sie können mehrere Video‑ oder Audiodateien auswählen, die als einzelne Clips in einer Zeitleiste erscheinen. Für jeden Clip können Start‑ und Endzeitpunkte festgelegt, die Reihenfolge verändert oder der Clip entfernt werden.
* **Alle Clips in der Vorschau abspielen:** Über den Button „Alle Vorschau“ werden alle Clips in der definierten Reihenfolge und Länge hintereinander abgespielt.
* **Clips exportieren:** Mit dem Button „Exportieren“ lassen sich alle zugeschnittenen Clips als ein einzelnes MP4‑Video zusammenfügen und herunterladen. Hierfür wird `ffmpeg.wasm` (WebAssembly) verwendet, sodass der Export vollständig im Browser erfolgt.
* **Integrierter Chatbereich:** Stellen Sie Fragen an ChatGPT. Es wird der OpenAI‑Chat‑Completion‑Endpunkt im Browser per Fetch aufgerufen.
* **API‑Key‑Eingabe:** Speichern Sie Ihren OpenAI‑API‑Schlüssel lokal im Browser (`localStorage`), sodass er nicht bei jedem Laden neu eingegeben werden muss.

## Nutzung

1. **API‑Key eingeben:** Tragen Sie Ihren OpenAI‑API‑Key in das entsprechende Feld ein und klicken Sie auf „Speichern“. Der Schlüssel wird nur lokal im Browser gespeichert.
2. **Clip(s) hinzufügen:** Klicken Sie auf „Clip hinzufügen“ und wählen Sie eine oder mehrere Video‑/Audiodateien aus. Jeder ausgewählte Clip erscheint in der Zeitleiste. Stellen Sie optional Start‑ und Endzeiten ein oder verschieben Sie die Clips per Auf‑/Ab‑Buttons.
3. **Clips in der Vorschau ansehen:** Mit dem Button „Alle Vorschau“ werden die Clips nacheinander abgespielt, wobei nur der definierte Zeitbereich jedes Clips zu sehen ist.
4. **Chat nutzen:** Stellen Sie eine Frage in das Chatfeld und klicken Sie auf „Senden“. Die Antwort von ChatGPT erscheint im Protokoll.
5. **Exportieren:** Wenn Ihre Clip‑Reihenfolge und Schnitte feststehen, klicken Sie auf „Exportieren“. Die Anwendung exportiert die Clips nacheinander zu einem einzelnen MP4‑Video und startet einen Download der fertigen Datei.

## Hosting auf GitHub Pages

Um diese Webanwendung online bereitzustellen, können Sie die Dateien in ein öffentliches GitHub‑Repository hochladen und GitHub Pages aktivieren:

1. Erstellen Sie ein neues Repository auf GitHub (z. B. `video-editor-online`).
2. Laden Sie die Dateien aus diesem Ordner in das Repository hoch (`index.html`, `script.js`, `README.md`).
3. Aktivieren Sie in den Repository‑Einstellungen GitHub Pages (Branch `main` oder `master` und Ordner `/root`).
4. Nach kurzer Zeit ist die Anwendung unter `https://<IhrGitHubName>.github.io/<RepositoryName>/` erreichbar.

Alternativ können Sie die `index.html` auch lokal öffnen, indem Sie sie per Doppelklick im Browser starten.

## Hinweise

* Der API‑Key wird lokal im Browser gespeichert; geben Sie ihn nicht weiter. Für eine sichere öffentliche Bereitstellung sollte ein serverseitiger Proxy für die ChatGPT‑Anfragen eingerichtet werden, um den Schlüssel zu verbergen.
* Da die Anwendung vollständig clientseitig ist, müssen Videodateien lokal ausgewählt werden und können nicht im Browser gespeichert werden.

Viel Spaß beim Ausprobieren und erweitern!